import Nav from "@/components/nav"
import PageHeader from "@/components/page-header"
import StatCard from "@/components/stat-card"
import ThreatPill from "@/components/threat-pill"
import MapPlaceholder from "@/components/map-placeholder"
import MiniAreaChart from "@/components/charts/mini-area"

export default function DashboardPage() {
  return (
    <main className="min-h-dvh bg-[color:var(--bg)]">
      <Nav />
      <PageHeader
        title="Coastal Threat Dashboard"
        subtitle="Real-time monitoring, predictions, and alerts"
        right={<ThreatPill level="moderate" label="Current Threat: Moderate" />}
      />
      <section className="mx-auto max-w-6xl px-4 py-6 md:py-8">
        {/* Top: map + stats */}
        <div className="grid gap-6 md:grid-cols-3">
          <div className="md:col-span-2">
            <div className="rounded-xl border bg-white p-4 shadow-sm">
              <h2 className="text-lg font-semibold text-[color:var(--fg)]">Coastal Overview</h2>
              <div className="mt-3">
                <MapPlaceholder />
              </div>
              <div className="mt-4 flex flex-wrap items-center gap-2">
                <ThreatPill level="moderate" label="Storm Surge Watch" />
                <ThreatPill level="low" label="Erosion Risk: Low" />
                <ThreatPill level="high" label="Localized Flooding Advisory" />
              </div>
            </div>
          </div>
          <div className="space-y-4">
            <div className="rounded-xl border bg-white p-4 shadow-sm">
              <h3 className="text-sm font-medium text-[color:var(--fg)]">Key Metrics</h3>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <StatCard label="Wave Height" value="1.8 m" delta="+0.3m" intent="high" />
                <StatCard label="Wind Speed" value="22 kt" delta="+5kt" intent="moderate" />
                <StatCard label="Tide Level" value="0.4 m" delta="-0.1m" />
                <StatCard label="Pressure" value="1003 hPa" delta="-2hPa" intent="moderate" />
              </div>
            </div>
            <div className="rounded-xl border bg-white p-4 shadow-sm">
              <h3 className="text-sm font-medium text-[color:var(--fg)]">Live Trend (demo)</h3>
              <div className="mt-2">
                <MiniAreaChart />
              </div>
            </div>
          </div>
        </div>

        {/* Bottom: advisories and notes */}
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          <div className="rounded-xl border bg-white p-4 shadow-sm md:col-span-2">
            <h3 className="text-lg font-semibold text-[color:var(--fg)]">Active Advisories</h3>
            <ul className="mt-3 list-disc space-y-2 pl-5 text-sm leading-relaxed">
              <li>Localized flooding possible during high tide.</li>
              <li>Small craft advisory in effect until 6 PM.</li>
              <li>Beach erosion expected at exposed headlands.</li>
            </ul>
          </div>
          <div className="rounded-xl border bg-white p-4 shadow-sm">
            <h3 className="text-lg font-semibold text-[color:var(--fg)]">Notes</h3>
            <p className="mt-2 text-sm leading-relaxed text-[color:var(--fg)]">
              Front-end preview only. Replace placeholders with API data from your Express backend when ready.
            </p>
          </div>
        </div>
      </section>
    </main>
  )
}
