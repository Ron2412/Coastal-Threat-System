import Nav from "@/components/nav"
import PageHeader from "@/components/page-header"
import PredictionArea from "@/components/charts/prediction-area"
import ThreatPill from "@/components/threat-pill"

export default function PredictionsPage() {
  return (
    <main className="min-h-dvh bg-[color:var(--bg)]">
      <Nav />
      <PageHeader
        title="Predictions"
        subtitle="24–48 hour forecast horizon with confidence intervals"
        right={<ThreatPill level="moderate" label="Forecast: Moderate" />}
      />
      <section className="mx-auto max-w-6xl px-4 py-6 md:py-8">
        <div className="rounded-xl border bg-white p-4 shadow-sm">
          <h2 className="text-lg font-semibold text-[color:var(--fg)]">Water Level Forecast (demo)</h2>
          <div className="mt-3">
            <PredictionArea />
          </div>
          <p className="mt-3 text-sm text-[color:var(--muted)]">
            Past vs predicted comparison and Prophet output will appear here.
          </p>
        </div>
      </section>
    </main>
  )
}
