"use client"
import CoastalHeader from "@/components/coastal/header"
import MapPlaceholder from "@/components/coastal/map-placeholder"
import Legend from "@/components/coastal/legend"
import { Card } from "@/components/coastal/card"
import { Stat } from "@/components/coastal/stat"
import { ThreatBadge } from "@/components/coastal/threat-badge"

export default function DemoPage() {
  return (
    <main className="min-h-dvh bg-[color:var(--bg)]">
      <CoastalHeader />

      <section className="mx-auto max-w-6xl px-4 py-6 md:py-8">
        {/* Top grid: map + side panel */}
        <div className="grid gap-6 md:grid-cols-3">
          <div className="md:col-span-2">
            <Card title="Coastal Overview">
              <MapPlaceholder />
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <ThreatBadge level="moderate" label="Current Threat: Moderate" />
                <ThreatBadge level="high" label="Storm Surge Watch" />
                <ThreatBadge level="low" label="Erosion Risk: Low" />
              </div>
            </Card>
          </div>
          <div className="space-y-6">
            <Legend />
            <Card title="Key Metrics">
              <div className="grid gap-3 sm:grid-cols-2">
                <Stat label="Wave Height" value="1.8 m" delta="+0.3m" intent="bad" />
                <Stat label="Wind Speed" value="22 kt" delta="+5kt" />
                <Stat label="Tide Level" value="0.4 m" delta="-0.1m" intent="good" />
                <Stat label="Pressure" value="1003 hPa" delta="-2hPa" intent="bad" />
              </div>
            </Card>
          </div>
        </div>

        {/* Bottom cards */}
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          <Card title="Advisories" footer="Source: Coastal Authority">
            <ul className="list-disc space-y-2 pl-5 text-sm leading-relaxed">
              <li>Localized flooding possible during high tide.</li>
              <li>Small craft advisory in effect until 6 PM.</li>
              <li>Beach erosion expected at exposed headlands.</li>
            </ul>
          </Card>
          <Card title="Next 24h">
            <p className="text-sm leading-relaxed">
              Conditions trending towards elevated surge risk. Monitor coastal alerts and prepare mitigation steps if
              traveling near low-lying areas.
            </p>
          </Card>
          <Card title="Notes">
            <p className="text-sm leading-relaxed">
              This is a front-end preview. Replace placeholder map and metrics with your live data when backend is
              ready.
            </p>
          </Card>
        </div>
      </section>
    </main>
  )
}
