import Nav from "@/components/nav"
import PageHeader from "@/components/page-header"
import ThreatPill from "@/components/threat-pill"

const active = [
  { id: "AL-2001", title: "Storm Surge Watch", level: "moderate" },
  { id: "AL-2002", title: "Localized Flooding Advisory", level: "high" },
]

const history = [
  { id: "AL-1998", title: "High Wind Advisory", level: "moderate", at: "Yesterday 18:10" },
  { id: "AL-1993", title: "Beach Erosion Risk", level: "low", at: "Yesterday 10:45" },
]

export default function AlertsPage() {
  return (
    <main className="min-h-dvh bg-[color:var(--bg)]">
      <Nav />
      <PageHeader
        title="Alerts"
        subtitle="Manage active alerts and notification preferences"
        right={<ThreatPill level="moderate" label="2 Active" />}
      />
      <section className="mx-auto max-w-6xl px-4 py-6 md:py-8">
        <div className="grid gap-6 md:grid-cols-2">
          <div className="rounded-xl border bg-white p-4 shadow-sm">
            <h2 className="text-lg font-semibold text-[color:var(--fg)]">Active Alerts</h2>
            <ul className="mt-3 space-y-3">
              {active.map((a) => (
                <li key={a.id} className="flex items-center justify-between gap-3 rounded-lg border px-3 py-2">
                  <div>
                    <p className="text-sm font-medium text-[color:var(--fg)]">{a.title}</p>
                    <p className="text-xs text-[color:var(--muted)]">{a.id}</p>
                  </div>
                  <ThreatPill level={a.level} />
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-xl border bg-white p-4 shadow-sm">
            <h2 className="text-lg font-semibold text-[color:var(--fg)]">History</h2>
            <ul className="mt-3 space-y-3">
              {history.map((h) => (
                <li key={h.id} className="flex items-center justify-between gap-3 rounded-lg border px-3 py-2">
                  <div>
                    <p className="text-sm font-medium text-[color:var(--fg)]">{h.title}</p>
                    <p className="text-xs text-[color:var(--muted)]">
                      {h.id} • {h.at}
                    </p>
                  </div>
                  <ThreatPill level={h.level} />
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </main>
  )
}
