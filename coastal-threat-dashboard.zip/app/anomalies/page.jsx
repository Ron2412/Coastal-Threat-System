import Nav from "@/components/nav"
import PageHeader from "@/components/page-header"
import ThreatPill from "@/components/threat-pill"

const rows = [
  { id: "A-1024", time: "10:14", sensor: "Buoy-7", metric: "Wave Height", severity: "high" },
  { id: "A-1025", time: "10:22", sensor: "Pier-3", metric: "Tide Level", severity: "moderate" },
  { id: "A-1026", time: "10:40", sensor: "Station-2", metric: "Pressure", severity: "low" },
]

export default function AnomaliesPage() {
  return (
    <main className="min-h-dvh bg-[color:var(--bg)]">
      <Nav />
      <PageHeader
        title="Anomaly Monitor"
        subtitle="Real-time detection using Isolation Forest"
        right={<ThreatPill level="high" label="Active Anomalies" />}
      />
      <section className="mx-auto max-w-6xl px-4 py-6 md:py-8">
        <div className="rounded-xl border bg-white p-4 shadow-sm">
          <h2 className="text-lg font-semibold text-[color:var(--fg)]">Recent Anomalies</h2>
          <div className="mt-3 overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="text-[color:var(--muted)]">
                <tr>
                  <th className="py-2">ID</th>
                  <th className="py-2">Time</th>
                  <th className="py-2">Sensor</th>
                  <th className="py-2">Metric</th>
                  <th className="py-2">Severity</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className="border-t">
                    <td className="py-2">{r.id}</td>
                    <td className="py-2">{r.time}</td>
                    <td className="py-2">{r.sensor}</td>
                    <td className="py-2">{r.metric}</td>
                    <td className="py-2">
                      <ThreatPill level={r.severity} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-3 text-sm text-[color:var(--muted)]">Alert history and visualization will appear here.</p>
        </div>
      </section>
    </main>
  )
}
