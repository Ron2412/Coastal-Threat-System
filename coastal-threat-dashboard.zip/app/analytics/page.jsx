import Nav from "@/components/nav"
import PageHeader from "@/components/page-header"
import MiniAreaChart from "@/components/charts/mini-area"
import ThreatPill from "@/components/threat-pill"

export default function AnalyticsPage() {
  return (
    <main className="min-h-dvh bg-[color:var(--bg)]">
      <Nav />
      <PageHeader
        title="Analytics"
        subtitle="Historical data and trends"
        right={<ThreatPill level="low" label="Normal" />}
      />
      <section className="mx-auto max-w-6xl px-4 py-6 md:py-8">
        <div className="grid gap-6 md:grid-cols-2">
          <div className="rounded-xl border bg-white p-4 shadow-sm">
            <h2 className="text-lg font-semibold text-[color:var(--fg)]">Wave Height Trend</h2>
            <div className="mt-2">
              <MiniAreaChart />
            </div>
          </div>
          <div className="rounded-xl border bg-white p-4 shadow-sm">
            <h2 className="text-lg font-semibold text-[color:var(--fg)]">Tide Level Trend</h2>
            <div className="mt-2">
              <MiniAreaChart />
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
