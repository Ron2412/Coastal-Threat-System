"use client"

import { useEffect, useState } from "react"
import Nav from "@/components/nav"
import PageHeader from "@/components/page-header"

export default function SettingsPage() {
  const [autoRefresh, setAutoRefresh] = useState(true)
  const [units, setUnits] = useState("metric") // metric or imperial

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("coastal_prefs") || "{}")
    if (saved.units) setUnits(saved.units)
    if (typeof saved.autoRefresh === "boolean") setAutoRefresh(saved.autoRefresh)
  }, [])

  useEffect(() => {
    localStorage.setItem("coastal_prefs", JSON.stringify({ autoRefresh, units }))
  }, [autoRefresh, units])

  return (
    <main className="min-h-dvh bg-[color:var(--bg)]">
      <Nav />
      <PageHeader title="Settings" subtitle="User preferences" />
      <section className="mx-auto max-w-6xl px-4 py-6 md:py-8">
        <div className="rounded-xl border bg-white p-4 shadow-sm">
          <h2 className="text-lg font-semibold text-[color:var(--fg)]">Preferences</h2>
          <div className="mt-4 grid gap-4 sm:max-w-md">
            <label className="flex items-center justify-between gap-4">
              <span className="text-sm text-[color:var(--fg)]">Auto-refresh every 30s</span>
              <input
                aria-label="Toggle auto refresh"
                type="checkbox"
                checked={autoRefresh}
                onChange={(e) => setAutoRefresh(e.target.checked)}
                className="h-5 w-5 accent-[color:var(--primary)]"
              />
            </label>
            <label className="text-sm text-[color:var(--fg)]">Units</label>
            <div className="flex items-center gap-3">
              <label className="inline-flex items-center gap-2">
                <input
                  type="radio"
                  name="units"
                  value="metric"
                  checked={units === "metric"}
                  onChange={() => setUnits("metric")}
                  className="h-4 w-4 accent-[color:var(--primary)]"
                />
                <span className="text-sm">Metric (m, kt)</span>
              </label>
              <label className="inline-flex items-center gap-2">
                <input
                  type="radio"
                  name="units"
                  value="imperial"
                  checked={units === "imperial"}
                  onChange={() => setUnits("imperial")}
                  className="h-4 w-4 accent-[color:var(--primary)]"
                />
                <span className="text-sm">Imperial (ft, mph)</span>
              </label>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
