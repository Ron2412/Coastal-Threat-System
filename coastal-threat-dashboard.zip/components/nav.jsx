// Colors limited to: primary(#0e5aa7), accent(#e15541), background, foreground, muted
"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

const links = [
  { href: "/", label: "Dashboard" },
  { href: "/predictions", label: "Predictions" },
  { href: "/anomalies", label: "Anomalies" },
  { href: "/alerts", label: "Alerts" },
  { href: "/analytics", label: "Analytics" },
  { href: "/settings", label: "Settings" },
]

export default function Nav() {
  const pathname = usePathname()
  return (
    <nav className="w-full border-b bg-[color:var(--bg)]">
      <div className="mx-auto max-w-6xl px-4">
        <div className="flex items-center justify-between py-3">
          <Link href="/" className="text-balance text-lg font-semibold text-[color:var(--fg)]">
            Coastal Threat
          </Link>
          <div className="flex items-center gap-1 overflow-x-auto">
            {links.map((l) => {
              const active = pathname === l.href
              return (
                <Link
                  key={l.href}
                  href={l.href}
                  className={cn(
                    "px-3 py-2 text-sm rounded-md border",
                    active
                      ? "bg-[color:var(--primary)] text-white border-transparent"
                      : "text-[color:var(--fg)] hover:bg-[color:var(--secondary,rgba(0,0,0,0.02))] border-transparent",
                  )}
                  aria-current={active ? "page" : undefined}
                >
                  {l.label}
                </Link>
              )
            })}
          </div>
        </div>
      </div>
    </nav>
  )
}
