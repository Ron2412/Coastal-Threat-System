"use client"

import { useEffect } from "react"
import { applyCSSVariables, colors } from "../theme"
import { cn } from "@/lib/utils"

export default function CoastalHeader({
  title = "Coastal Threat Dashboard",
  subtitle = "Real-time coastal risk indicators",
  className,
}) {
  useEffect(() => {
    applyCSSVariables()
  }, [])

  return (
    <header className={cn("w-full border-b bg-[color:var(--bg)]", className)}>
      <div className="mx-auto max-w-6xl px-4 py-5 md:py-6">
        <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-pretty text-2xl font-semibold tracking-tight text-[color:var(--fg)] md:text-3xl">
              {title}
            </h1>
            <p className="text-sm text-[color:var(--muted)] md:text-base">{subtitle}</p>
          </div>
          <div className="flex items-center gap-3">
            <span
              className="inline-flex items-center gap-2 rounded-md border px-3 py-1.5 text-sm"
              style={{ borderColor: "color-mix(in oklab, var(--primary) 30%, black)" }}
            >
              <span className="size-2 rounded-full" style={{ backgroundColor: colors.primary }} aria-hidden />
              Updated just now
            </span>
          </div>
        </div>
      </div>
    </header>
  )
}
