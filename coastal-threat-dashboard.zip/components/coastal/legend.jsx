const items = [
  { label: "Flooding", color: "#E15541" },
  { label: "Storm Surge", color: "#0E5AA7" },
  { label: "Erosion", color: "#6B7280" },
]

export default function Legend() {
  return (
    <div className="rounded-lg border bg-white p-4">
      <h3 className="text-sm font-medium text-[color:var(--fg)]">Legend</h3>
      <ul className="mt-3 space-y-2">
        {items.map((it) => (
          <li key={it.label} className="flex items-center gap-3 text-sm">
            <span className="size-3 rounded-sm" style={{ background: it.color }} aria-hidden />
            <span className="text-[color:var(--fg)]">{it.label}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}
