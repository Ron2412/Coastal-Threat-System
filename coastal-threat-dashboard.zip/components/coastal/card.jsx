import { cn } from "@/lib/utils"

export function Card({ title, children, className, footer }) {
  return (
    <section className={cn("rounded-xl border bg-white p-4 shadow-sm md:p-6", className)}>
      {title ? <h3 className="text-lg font-semibold text-[color:var(--fg)]">{title}</h3> : null}
      <div className={cn(title ? "mt-3" : "", "text-[color:var(--fg)]")}>{children}</div>
      {footer ? <div className="mt-4 border-t pt-3 text-sm text-[color:var(--muted)]">{footer}</div> : null}
    </section>
  )
}
