import { cn } from "@/lib/utils"

const intents = {
  low: "bg-emerald-50 text-emerald-700 border-emerald-200",
  moderate: "bg-amber-50 text-amber-800 border-amber-200",
  high: "bg-red-50 text-red-700 border-red-200",
}

export function ThreatBadge({ level = "moderate", label }) {
  const cls = intents[level] || intents.moderate
  return (
    <span className={cn("inline-flex items-center gap-2 rounded-md border px-2.5 py-1 text-xs font-medium", cls)}>
      <span className="size-1.5 rounded-full bg-current" aria-hidden />
      {label || `Threat: ${level}`}
    </span>
  )
}
