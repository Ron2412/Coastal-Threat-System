// Keep to 3-5 colors total per design guidelines.
export const colors = {
  // Primary brand: ocean blue
  primary: "#0E5AA7",
  // Neutrals
  background: "hsl(0 0% 100%)",
  foreground: "hsl(222 47% 11%)",
  muted: "hsl(215 16% 47%)",
  // Accent for alerts (coastal hazards)
  accent: "#E15541",
}

// Convenience Tailwind class strings (kept minimal)
export const tokens = {
  ring: "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[color:var(--ring)]",
}

export function applyCSSVariables() {
  if (typeof document === "undefined") return
  const root = document.documentElement
  root.style.setProperty("--bg", colors.background)
  root.style.setProperty("--fg", colors.foreground)
  root.style.setProperty("--muted", colors.muted)
  root.style.setProperty("--primary", colors.primary)
  root.style.setProperty("--accent", colors.accent)
  root.style.setProperty("--ring", colors.primary)
}
