"use client"

import { useEffect, useState } from "react"
import { cn } from "@/lib/utils"

export default function PageHeader({ title, subtitle, right }) {
  // simulate "last updated" pulse
  const [tick, setTick] = useState(0)
  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), 30000) // 30s (no backend)
    return () => clearInterval(id)
  }, [])
  return (
    <header className="w-full bg-[color:var(--bg)]">
      <div className="mx-auto max-w-6xl px-4 py-5 md:py-6">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-pretty text-2xl font-semibold tracking-tight text-[color:var(--fg)] md:text-3xl">
              {title}
            </h1>
            {subtitle ? <p className="text-sm text-[color:var(--muted)]">{subtitle}</p> : null}
          </div>
          <div className="flex items-center gap-2">
            <span
              className={cn(
                "inline-flex items-center gap-2 rounded-md border px-3 py-1.5 text-sm",
                "bg-white text-[color:var(--fg)]",
              )}
              aria-live="polite"
            >
              <span className="relative inline-flex h-2.5 w-2.5">
                <span
                  className="absolute inline-flex h-full w-full animate-ping rounded-full opacity-20"
                  style={{ backgroundColor: "var(--primary)" }}
                />
                <span
                  className="relative inline-flex h-2.5 w-2.5 rounded-full"
                  style={{ backgroundColor: "var(--primary)" }}
                />
              </span>
              Updated {tick === 0 ? "just now" : `${tick * 30}s ago`}
            </span>
            {right}
          </div>
        </div>
      </div>
    </header>
  )
}
