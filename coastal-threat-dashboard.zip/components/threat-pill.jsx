import { cn } from "@/lib/utils"

const styles = {
  low: "border border-[color:var(--border)] bg-white text-[color:var(--fg)]",
  moderate: "border border-transparent bg-[color:var(--primary)] text-white",
  high: "border border-transparent bg-[color:var(--accent)] text-white",
  critical: "border-2 border-[color:var(--accent)] bg-white text-[color:var(--accent)]",
}

export default function ThreatPill({ level = "moderate", label }) {
  const cls = styles[level] || styles.moderate
  return (
    <span className={cn("inline-flex items-center gap-2 rounded-md px-2.5 py-1 text-xs font-medium", cls)}>
      <span
        className="h-1.5 w-1.5 rounded-full"
        style={{
          background: level === "low" ? "var(--fg)" : level === "moderate" ? "var(--primary)" : "var(--accent)",
        }}
        aria-hidden
      />
      {label || `Threat: ${level}`}
    </span>
  )
}
