import { cn } from "@/lib/utils"

export default function StatCard({ label, value, delta, intent = "neutral", className }) {
  const color =
    intent === "high" || intent === "critical"
      ? "text-[color:var(--accent)]"
      : intent === "moderate"
        ? "text-[color:var(--primary)]"
        : "text-[color:var(--fg)]"

  return (
    <div className={cn("rounded-lg border bg-white p-4 shadow-sm", "flex flex-col gap-1", className)}>
      <span className="text-xs uppercase tracking-wide text-[color:var(--muted)]">{label}</span>
      <div className="flex items-baseline gap-2">
        <span className={cn("text-2xl font-semibold", color)}>{value}</span>
        {delta ? <span className="text-xs text-[color:var(--muted)]">{delta}</span> : null}
      </div>
    </div>
  )
}
