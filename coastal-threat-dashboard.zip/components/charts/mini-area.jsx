"use client"

import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

const data = [
  { t: "00:00", v: 1.1 },
  { t: "03:00", v: 1.2 },
  { t: "06:00", v: 1.8 },
  { t: "09:00", v: 1.6 },
  { t: "12:00", v: 1.9 },
  { t: "15:00", v: 2.0 },
  { t: "18:00", v: 1.7 },
  { t: "21:00", v: 1.5 },
]

export default function MiniAreaChart() {
  return (
    <div className="h-28 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ left: 8, right: 8, top: 10, bottom: 0 }}>
          <defs>
            <linearGradient id="fillPrimary" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.35} />
              <stop offset="100%" stopColor="var(--primary)" stopOpacity={0.05} />
            </linearGradient>
          </defs>
          <XAxis dataKey="t" hide />
          <YAxis hide />
          <Tooltip cursor={{ stroke: "rgba(0,0,0,0.1)" }} />
          <Area type="monotone" dataKey="v" stroke="var(--primary)" fill="url(#fillPrimary)" strokeWidth={2} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}
