"use client"

import { Area, AreaChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

const data = [
  { t: "Now", low: 1.2, pred: 1.4, high: 1.6 },
  { t: "+3h", low: 1.1, pred: 1.5, high: 1.8 },
  { t: "+6h", low: 1.0, pred: 1.6, high: 2.0 },
  { t: "+9h", low: 1.1, pred: 1.7, high: 2.2 },
  { t: "+12h", low: 1.2, pred: 1.8, high: 2.3 },
  { t: "+15h", low: 1.1, pred: 1.7, high: 2.2 },
  { t: "+18h", low: 1.0, pred: 1.6, high: 2.0 },
  { t: "+21h", low: 0.9, pred: 1.5, high: 1.9 },
  { t: "+24h", low: 0.8, pred: 1.4, high: 1.8 },
]

export default function PredictionArea() {
  return (
    <div className="h-72 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ left: 8, right: 8, top: 10, bottom: 0 }}>
          <defs>
            <linearGradient id="band" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.15} />
              <stop offset="100%" stopColor="var(--primary)" stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <XAxis dataKey="t" stroke="var(--muted)" />
          <YAxis stroke="var(--muted)" />
          <Tooltip />
          {/* Confidence band by stacking areas */}
          <Area type="monotone" dataKey="high" stroke="transparent" fill="url(#band)" />
          <Area type="monotone" dataKey="low" stroke="transparent" fill="var(--background)" />
          {/* Prediction line */}
          <Line type="monotone" dataKey="pred" stroke="var(--primary)" strokeWidth={2} dot={false} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}
