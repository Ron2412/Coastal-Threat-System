export default function MapPlaceholder() {
  return (
    <div className="relative aspect-[16/10] w-full overflow-hidden rounded-xl border bg-[color:var(--bg)]">
      <div className="absolute inset-0 grid grid-cols-6 grid-rows-4 opacity-40">
        {Array.from({ length: 24 }).map((_, i) => (
          <div key={i} className="border border-dashed border-gray-200" />
        ))}
      </div>
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="rounded-md border bg-white/80 px-3 py-1.5 text-sm text-[color:var(--muted)]">
          Map preview (placeholder)
        </div>
      </div>
    </div>
  )
}
